﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommunicationApplication.UI.Interface_Abstract
{
    /// <summary>
    /// 모델들은 해당 인터페이스를 상속 받아야합니다.
    /// </summary>
    internal interface IModelBase
    {
    }
}
