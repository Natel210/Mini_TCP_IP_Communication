﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CommunicationApplication.UI;

namespace CommunicationApplication.UI.MainWindow
{
    internal class Mainwindow_Model : Interface_Abstract.IModelBase
    {
    }
}
