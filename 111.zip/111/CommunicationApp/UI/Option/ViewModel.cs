﻿using CommunicationApp.UI.Base;
namespace CommunicationApp.UI.Option
{
    //public class ViewModel : AViewModelBase
    //{
    //    Model model = new Model();
    //    public ViewModel() : base()
    //    {
    //        ModelData = model;
    //    }
    //}
}
