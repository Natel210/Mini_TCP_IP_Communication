﻿using CommunicationApp.UI.Base;

namespace CommunicationApp.UI.Main
{
    internal class Model : IModelBase
    {
    }
}
